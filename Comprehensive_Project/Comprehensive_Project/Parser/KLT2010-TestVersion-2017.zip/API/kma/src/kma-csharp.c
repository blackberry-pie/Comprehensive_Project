/*--------------------------------------------------------------------------
	File-name	: coran.c
	Description	: Example of calling Korean Morph. Analyser
			  Hangul I/O code is KSC-5601-1987
	Written-by	: Kang, Seung-Shik at Kookmin University  2001. 6.
----------------------------------------------------------------------------*/
#include "../header/ham-kma.h"

extern void hamout_HAM(FILE *fp, HAM_PMORES p, HAM_PRUNMODE mode);	// out_ham_csharp.c

/*
	Set I/O types: following 3 types are possible.
		1. stdin & stdout
		2. file input & stdout
		3. file input & file output
*/
int set_iofile_ptr(argc, argv, fpin, fpout)
int argc;
char *argv[];
FILE **fpin;
FILE **fpout;
{
	int i=1, nargs=argc;

	if (argc > 1 && argv[1][0] == '-') { i++; nargs--; }

	switch (nargs) {
	case 1:
		if (argc == 1) { return 1; }
		break;
	case 2:
		*fpin = fopen(argv[i], "r");
		if (!*fpin) { printf("No such file <%s>\n", argv[i]); return 1; }
		break;
	case 3:
		*fpin = fopen(argv[i], "r");
		if (!*fpin) { printf("No such file <%s>\n", argv[i]); return 1; }
		if (*fpout = fopen(argv[i+1], "r")) {
			fprintf(stderr, "Overwrite output file <%s> ? ", argv[i+1]);
			if (tolower(fgetc(stdin)) != 'y') return 1;
		}
		*fpout = fopen(argv[i+1], "wb");
		break;
	default:
		return 1;
	}

	return 0;
}

main_ORG(argc, argv)
int argc;
char *argv[];
{
	FILE *fpin=stdin, *fpout=stdout;
	HAM_RUNMODE mode;	/* HAM running mode: 'header/runmode.h' */
	int flag;

	unsigned char sent[SENTSIZE];	/* input sentence */
	HAM_PMORES hamout1;	/* frame-based morph. analysis output */

	if (set_iofile_ptr(argc, argv, &fpin, &fpout))
		return 0;	/* I/O files open failed */

	flag = open_HAM(&mode, NULL, "./hdic/KLT2000.ini");
	while (fscanf(fpin, "%s", sent) == 1) {
		hamout1 = morph_anal(sent, NULL, &mode);
		hamout_HAM(fpout, hamout1, &mode);
	}

	if (fpin != stdin) fclose(fpin);
	if (fpout != stdout) fclose(fpout);
	GOODBYE(2013);	/* good-bye message: 'header/ham-kma.h' */
	
	return 0;
}

HAM_MORES KmaResult;
extern PREFIX int morph_anal_Csharp1(char *sent, HAM_PMORES hamout, char *inifile);

main_Csharp_TEST(argc, argv)
int argc;
char *argv[];
{
	FILE *fpin=stdin, *fpout=stdout;
	HAM_RUNMODE mode;	/* HAM running mode: 'header/runmode.h' */
	int flag;
	unsigned char sent[SENTSIZE];	/* input sentence */

	if (set_iofile_ptr(argc, argv, &fpin, &fpout))
		return 0;	/* I/O files open failed */

	while (fscanf(fpin, "%s", sent) == 1) {
		flag = morph_anal_Csharp1(sent, &KmaResult, "./hdic/KLT2000.ini");
		if (flag == 0) continue;
		mode.outmode = mode.echosent = mode.echoword = mode.hcode_out = 1;	// 'mode'�� �ʱ�ȭ�Ǿ� ���� ���� -- �ӽ÷� ���
		hamout_HAM(fpout, &KmaResult, &mode);
	}

	if (fpin != stdin) fclose(fpin);
	if (fpout != stdout) fclose(fpout);
	GOODBYE(2013);	/* good-bye message: 'header/ham-kma.h' */
	
	return 0;
}

extern PREFIX HAM_MORES morph_anal_Csharp(char *sent, char *inifile);

main(argc, argv)
int argc;
char *argv[];
{
	FILE *fpin=stdin, *fpout=stdout;
	HAM_RUNMODE mode;	/* HAM running mode: 'header/runmode.h' */
	unsigned char sent[SENTSIZE];	/* input sentence */

	if (set_iofile_ptr(argc, argv, &fpin, &fpout))
		return 0;	/* I/O files open failed */

	while (fscanf(fpin, "%s", sent) == 1) {
		KmaResult = morph_anal_Csharp(sent, "./hdic/KLT2000.ini");
		mode.outmode = mode.echosent = mode.echoword = mode.hcode_out = 1;	// 'mode'�� �ʱ�ȭ�Ǿ� ���� ���� -- �ӽ÷� ���
		hamout_HAM(fpout, &KmaResult, &mode);
		// <����> i��° ������ ���� �м� ��� ���� KmaResult.word[i].gr[0] == 0 �̸� �м���� ����
	}

	if (fpin != stdin) fclose(fpin);
	if (fpout != stdout) fclose(fpout);
	GOODBYE(2013);	/* good-bye message: 'header/ham-kma.h' */
	
	return 0;
}
/*--------------------------- end of kma.c --------------------------*/
